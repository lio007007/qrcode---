#hm_QRcode

[![Build status](https://ci.appveyor.com/api/projects/status/frechiuk78ga3c7l/branch/master?svg=true)](https://ci.appveyor.com/api/projects/status/frechiuk78ga3c7l/branch/master)

VS2013下 动图二维码生成器

详细介绍：https://www.fawdlstty.com/archives/292.html

##更新日志：

###2016-07-31 0.1.3

* 加入多帧图片和单帧图片验证
* 加入“裁剪背景为正方形”选项框
* 加入动图帧时间选项

###2016-07-26 0.1.2

* 加入简单的二维码大小识别，不用手动数大小
* 加入部分错误判断
* 加入二维码像素值设置
* 增加二维码绘图精度

###2016-07-25 0.1.1

* 完成原型设计